package com.multithreading;

import java.util.concurrent.BlockingQueue;

public class Consumer implements Runnable {

	BlockingQueue<Integer> blockingQueue;
	int consume = -1;

	public Consumer(BlockingQueue<Integer> blockingQueue)
    {
        this.blockingQueue = blockingQueue;
    }

	@Override
	public void run() {
		while (consume != 10) {
			try {
				consume = blockingQueue.take();
				System.out.println("Consumed " + consume);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

}
------------------------------------------------------------------------------------------
import java.util.concurrent.BlockingQueue;

public class Producer implements Runnable {

	BlockingQueue<Integer> blockingQueue;

	public Producer(BlockingQueue<Integer> blockingQueue) {
		this.blockingQueue = blockingQueue;
	}

	@Override
	public void run() {
		for (int i = 1; i <= 10; i++) {
			try {
				blockingQueue.put(i);
				System.out.println("Produced " + i);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

}
--------------------------------------------------------------------------------------------------------------------
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class BlockingQueueProducerConsumer {
	public static void main(String[] args) {

		BlockingQueue<Integer> blockingQueue = new ArrayBlockingQueue<Integer>(4);

		Producer producer = new Producer(blockingQueue);
		Consumer consumer = new Consumer(blockingQueue);

		Thread producerThread = new Thread(producer);
		Thread consumerThread = new Thread(consumer);

		producerThread.start();
		consumerThread.start();
	}
}